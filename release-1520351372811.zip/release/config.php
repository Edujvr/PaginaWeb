<?php
return [
    'CLIENT_ACCESS_TOKEN' => 'YOUR_CLIENT_ACCESS_TOKEN'
 ];
?>
